import tkinter as tk
from tkinter import ttk
import pickle

# Load the trained model
model = pickle.load(open("model.pkl", "rb"))

# Function to make predictions
def predict_price():
    try:
        rooms = int(rooms_var.get())
        lower_status = lower_status_var.get()

        if lower_status == "High":
            ptratio_value = 31.5
        elif lower_status == "Medium":
            ptratio_value = 20.5
        else:
            ptratio_value = 10

        student_teacher_ratio_choice = student_teacher_ratio_var.get()
        if student_teacher_ratio_choice == "Low":
            student_teacher_ratio = 16
        elif student_teacher_ratio_choice == "Medium":
            student_teacher_ratio = 18
        else:
            student_teacher_ratio = 20

        input_data = [[rooms, ptratio_value, student_teacher_ratio]]
        prediction = model.predict(input_data)

        result_label.config(text=f"Predicted Price: ${prediction[0]:,.2f}")
    except Exception as e:
        result_label.config(text=f"Error: {str(e)}")

# Create the main window
root = tk.Tk()
root.title("House Pricing Prediction")
root.geometry("700x700")
root.config(bg="gray")

# Center the window on the screen
root.update_idletasks()
window_width = root.winfo_width()
window_height = root.winfo_height()
position_top = int(root.winfo_screenheight() / 2 - window_height / 2)
position_right = int(root.winfo_screenwidth() / 2 - window_width / 2)
root.geometry(f"+{position_right}+{position_top}")

# Create a black border frame to wrap everything
main_frame = tk.Frame(root, bg="black", padx=10, pady=10)
main_frame.place(relx=0.5, rely=0.5, anchor="center")

# Add the form area (inner frame)
form_frame = tk.Frame(main_frame, bg="lightgray", padx=20, pady=20)
form_frame.pack()

# Title
header_label = tk.Label(form_frame, text="House Pricing Prediction", font=("Arial", 22, "bold"), fg="white", bg="darkblue", pady=10, padx=20)
header_label.grid(row=0, column=0, columnspan=2, pady=10)

# Input fields
rooms_label = tk.Label(form_frame, text="Number of Rooms:", font=("Arial", 14), bg="lightgray")
rooms_label.grid(row=1, column=0, padx=10, pady=10, sticky="w")
rooms_var = tk.StringVar()
rooms_dropdown = ttk.Combobox(form_frame, textvariable=rooms_var, values=[1, 2, 3, 4, 5], state="readonly", font=("Arial", 12))
rooms_dropdown.grid(row=1, column=1, padx=10, pady=10)

lower_status_label = tk.Label(form_frame, text="Lower Status of the Population:", font=("Arial", 14), bg="lightgray")
lower_status_label.grid(row=2, column=0, padx=10, pady=10, sticky="w")
lower_status_var = tk.StringVar()
lower_status_dropdown = ttk.Combobox(form_frame, textvariable=lower_status_var, values=['High', 'Medium', 'Low'], state="readonly", font=("Arial", 12))
lower_status_dropdown.grid(row=2, column=1, padx=10, pady=10)

student_teacher_ratio_label = tk.Label(form_frame, text="Student to Teacher Ratio:", font=("Arial", 14), bg="lightgray")
student_teacher_ratio_label.grid(row=3, column=0, padx=10, pady=10, sticky="w")
student_teacher_ratio_var = tk.StringVar()
student_teacher_ratio_dropdown = ttk.Combobox(form_frame, textvariable=student_teacher_ratio_var, values=['Low', 'Medium', 'High'], state="readonly", font=("Arial", 12))
student_teacher_ratio_dropdown.grid(row=3, column=1, padx=10, pady=10)

# Predict Button
predict_button = tk.Button(form_frame, text="Predict Price", command=predict_price, font=("Arial", 14, "bold"), bg="darkblue", fg="white")
predict_button.grid(row=4, column=0, columnspan=2, pady=20)

# Result Label
result_label = tk.Label(form_frame, text="Predicted Price: $0.00", font=("Arial", 14, "bold"), bg="lightgray")
result_label.grid(row=5, column=0, columnspan=2, pady=10)

# Start the GUI
root.mainloop()
